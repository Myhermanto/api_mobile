<?php
require "connect.php";

if ($_SERVER['REQUEST_METHOD'] == "POST" || $_SERVER['REQUEST_METHOD'] == "GET") {
	$response = array();
	$nim = $_REQUEST['nim'];
	$nama = $_REQUEST['nama_lengkap'];
	$kelas = $_REQUEST['kelas'];
	$mtk = $_REQUEST['mtk'];
	$kampus = $_REQUEST['kampus'];

	$cek = "SELECT * FROM mhs WHERE nim='$nim'";
	$result = mysqli_fetch_array(mysqli_query($con, $cek));

	if (isset($result)) {
		$response['value'] = 2;
		$response['message'] = "Data Telah Terdaftar";
		echo json_encode($response);
	} else {
		$insert = "INSERT INTO mhs (nim, nama_lengkap, kelas, mtk, kampus, tgl_create) 
                   VALUES ('$nim', '$nama', '$kelas', '$mtk', '$kampus', NOW())";

		if (mysqli_query($con, $insert)) {
			$response['value'] = 1;
			$response['message'] = "Data Berhasil Tersimpan";
			echo json_encode($response);
		} else {
			$response['value'] = 0;
			$response['message'] = "Data Gagal Tersimpan";
			echo json_encode($response);
		}
	}
}