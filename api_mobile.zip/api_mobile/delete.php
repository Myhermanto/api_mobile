<?php
require "connect.php"; // Pastikan file ini berisi koneksi ke database

// Pastikan metode request adalah POST
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $response = array();

    // Pastikan parameter 'nim' ada dalam request
    if (isset($_POST['nim'])) {
        $nim = $_POST['nim'];

        // Cek apakah data dengan NIM ini ada di database
        $cek = "SELECT * FROM mhs WHERE nim='$nim'";
        $result = mysqli_query($con, $cek);

        if (mysqli_num_rows($result) > 0) {
            // Jika data ditemukan, lakukan delete
            $delete = "DELETE FROM mhs WHERE nim='$nim'";
            if (mysqli_query($con, $delete)) {
                $response['value'] = 1;
                $response['message'] = "Data berhasil dihapus";
            } else {
                $response['value'] = 0;
                $response['message'] = "Data gagal dihapus";
            }
        } else {
            // Jika data tidak ditemukan
            $response['value'] = 2;
            $response['message'] = "Data tidak ditemukan";
        }
    } else {
        // Jika parameter 'nim' tidak ada
        $response['value'] = 3;
        $response['message'] = "NIM tidak ditemukan dalam request";
    }

    // Kembalikan respons dalam format JSON
    echo json_encode($response);
}