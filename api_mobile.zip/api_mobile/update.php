<?php
require "connect.php"; 

// Pastikan metode request adalah POST
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $response = array();

    // Pastikan parameter 'nim' ada dalam request
    if (isset($_POST['nim']) && isset($_POST['nama_lengkap']) && isset($_POST['kelas']) && isset($_POST['mtk']) && isset($_POST['kampus'])) {
        $nim = $_POST['nim'];
        $nama = $_POST['nama_lengkap'];
        $kelas = $_POST['kelas'];
        $mtk = $_POST['mtk'];
        $kampus = $_POST['kampus'];

        // Cek apakah data dengan NIM ini ada di database
        $cek = "SELECT * FROM mhs WHERE nim='$nim'";
        $result = mysqli_query($con, $cek);

        if (mysqli_num_rows($result) > 0) {
            // Jika data ditemukan, lakukan update
            $update = "UPDATE mhs SET nama_lengkap='$nama', kelas='$kelas', mtk='$mtk', kampus='$kampus' WHERE nim='$nim'";

            if (mysqli_query($con, $update)) {
                $response['value'] = 1;
                $response['message'] = "Data berhasil diperbarui";
            } else {
                $response['value'] = 0;
                $response['message'] = "Data gagal diperbarui";
            }
        } else {
            // Jika data tidak ditemukan
            $response['value'] = 2;
            $response['message'] = "Data tidak ditemukan";
        }
    } else {
        // Jika parameter yang dibutuhkan tidak lengkap
        $response['value'] = 3;
        $response['message'] = "Data tidak lengkap dalam request";
    }

    // Kembalikan respons dalam format JSON
    echo json_encode($response);
}