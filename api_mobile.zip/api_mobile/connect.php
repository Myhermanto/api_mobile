<?php

define('HOST', 'localhost');
define('USER', 'root');
define('PASS', '');
define('DB', 'api_project');


$con = mysqli_connect(HOST, USER, PASS, DB) or die('Gagal Koneksi');