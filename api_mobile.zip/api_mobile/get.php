<?php
require "connect.php"; // Pastikan file ini berisi koneksi ke database

// Pastikan metode request adalah GET
if ($_SERVER['REQUEST_METHOD'] == "GET") {
    $response = array();

    // Query untuk mengambil data dari tabel mhs
    $query = "SELECT * FROM mhs";
    $result = mysqli_query($con, $query);

    if (mysqli_num_rows($result) > 0) {
        // Jika data ditemukan, simpan data dalam array
        $response['value'] = 1;
        $response['message'] = "Data ditemukan";
        $response['data'] = array();

        while ($row = mysqli_fetch_assoc($result)) {
            $data = array(
                'nim' => $row['nim'],
                'nama_lengkap' => $row['nama_lengkap'],
                'kelas' => $row['kelas'],
                'mtk' => $row['mtk'],
                'kampus' => $row['kampus'],
                'tgl_create' => $row['tgl_create']
            );

            array_push($response['data'], $data);
        }
    } else {
        // Jika data tidak ditemukan
        $response['value'] = 0;
        $response['message'] = "Data tidak ditemukan";
    }

    // Kembalikan respons dalam format JSON
    echo json_encode($response);
}